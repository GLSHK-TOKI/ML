export { VertexAIMultimodalEmbeddingConfig } from './multimodal_embedding_model_config.js';
export { VertexAIInstanceConfig } from './instance_config.js';
export { VertexAIMultimodalEmbeddingModel } from './multimodal_embedding_model.js';