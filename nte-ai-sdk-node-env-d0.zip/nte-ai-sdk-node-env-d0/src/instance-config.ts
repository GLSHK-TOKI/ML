export abstract class BaseInstanceConfig {
    protected constructor() {
    }
}