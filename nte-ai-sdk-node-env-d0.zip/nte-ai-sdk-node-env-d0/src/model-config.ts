export abstract class BaseModelConfig {
    protected constructor() {
    }
}