import LOGGER_CONFIG from '../configs/logger.js';
import pino from 'pino';

export default pino(LOGGER_CONFIG);
